<?php
/**
 * The header for our theme.
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package shuky
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
    <head>
        <meta charset="<?php bloginfo('charset'); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="profile" href="http://gmpg.org/xfn/11">
        <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">
        <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/menu-style.css">
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

        <!-- Optional theme -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">
<script type="text/javascript" src="https://static.hsstatic.net/jquery-libs/static-1.1/jquery/jquery-1.7.1.js"></script>
        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>

        <script type="text/javascript">
            jQuery(document).ready(function () {
                jQuery(window).bind('scroll', function () {
                    if (jQuery(window).scrollTop() >= 1) {
                        jQuery('#masthead').addClass('fixed-nav animated slideInDown');
                    }
                    else {
                        jQuery('#masthead').removeClass('fixed-nav animated slideInDown');
                    }
                });


                jQuery(document).on('click', 'button.navbar-toggle', function (event) {
                    jQuery('.site-navigation.collapse').toggleClass('in');
                });


                jQuery("#main-nav-menu").delegate("li.mobile-heading .fa-sort-down", "click", function (e) {
                    jQuery("#main-nav-menu .menu-open").removeClass("menu-open");
                    jQuery(this).parent().addClass("menu-open");
                });
                jQuery("#main-nav-menu").delegate("li.menu-open .fa-sort-down", "click", function (e) {
                    jQuery("#main-nav-menu .menu-open").removeClass("menu-open");
                });
            });
            jQuery(document).ready(function () {
                //jQuery('#mobile-menu').on('click', function (event) {
                //   // jQuery('.my_header_menu_class').toggleClass('open');
               // });
            });
        </script>
        <?php wp_head(); ?>
    </head>

    <body <?php body_class(); ?>>
        <div id="page" class="site">
            <a class="skip-link screen-reader-text" href="#main"><?php esc_html_e('Skip to content', 'shuky'); ?></a>

            <header id="masthead" class="site-header" role="banner">
                <div class="container">
                    <div class="col-md-3 col-sm-3">
                    <div class="site-branding">
                        <a href="<?php echo get_site_url(); ?>"><?php dynamic_sidebar( 'logo' ); ?></a>
                    </div><!-- .site-branding -->
                </div>
                    <div class="col-md-9 col-sm-9">
                        <div class="mobile-button">
                            <button type="button" class="navbar-toggle visible-xs visible-sm" data-toggle="collapse" data-target=".site-navigation">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                        </div>
                        <nav id="primary-navigation" class="site-navigation primary-navigation navbar-collapse collapse" role="navigation">

                            <?php
                            $walk = new My_Walker();
                            wp_nav_menu(array(
                                'theme_location' => 'header-menu',
                                'menu_id' => 'main-menu',
                                'menu_class' => 'nav navbar-nav navbar-right',
                                'items_wrap' => '<ul id="main-nav-menu">%3$s</ul>',
                                'walker' => $walk)
                            );
                            ?>
                        </nav>
                    </div>
                </div>
            </header><!-- #masthead -->

            <div id="content" class="site-content container">
