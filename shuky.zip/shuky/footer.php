<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package shuky
 */

?>

	</div><!-- #content -->

	<footer id="colophon" class="site-footer" role="contentinfo">

			<div class="top-footer">
			<div class="container">
			<div class="col-md-3 col-sm-3"><?php dynamic_sidebar('footer-col-1');?></div>
			<div class="col-md-3 col-sm-3"><?php dynamic_sidebar('footer-col-2');?></div>
			<div class="col-md-3 col-sm-3"><?php dynamic_sidebar('footer-col-3');?></div>
			<div class="col-md-3 col-sm-3"><?php dynamic_sidebar('footer-col-4');?></div>
			</div>

			</div>
			<div class="botom-footer">
			<div class="container">
				<div class="site-info">
				<?php
$publish_year = 2016;
$current_year = date('Y');
if ($current_year == $publish_year) {?>
    <span>&copy;&nbsp;copyright&nbsp;</span><span><?php echo $publish_year ?></span>
<?php } else {?>
        <span>&copy;&nbsp;copyright&nbsp;</span><span><?php echo $publish_year . '&nbsp;-&nbsp;' . $current_year ?></span>
     <?php }
?>
			<span class="sep"> | </span><span><a href="<?php echo get_site_url(); ?>"><?php bloginfo('name');?></a></span>

		</div><!-- .site-info -->
			</div>
			</div>

	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer();?>

</body>
</html>
